#include <iostream>

using namespace std;

/*
    Temat: Biuro posrednictwa pracy
*/

void systemLog(string msg)
{
    cout << "SYSTEM: " << msg<< endl;
}

///////////////////////////////////////////////////////////////////

class Job
{
public:
    Job() :
        name("nie-podano"),
        description("nie-podano"),
        releaseDate("1900-1-1")
    {
        systemLog("Wywolano konstruktor domyslny");
    }

    Job(string n, string d, string rd) :
        name(n),
        description(d),
        releaseDate(rd)
    {
        systemLog("Wywolano konstruktor z parametrami");
    }

    void setName(string n)
    {
        name = n;
    }

    void setDescription(string d)
    {
        description = d;
    }

    void setData(string n, string d, string rd)
    {
        setName(n);
        setDescription(d);
        releaseDate = rd;
    }

    void printData() const
    {
        cout << endl << " - Informacje o pracy -" << endl;
        cout << "Nazwa: " << getName() << endl;
        cout << "Opis: " << getDescription() << endl;
        cout << "Data wystawienia: " << releaseDate << endl;
        cout << "---------------------------" << endl << endl;
    }

    string getName() const
    {
        return name;
    }

    string getDescription() const
    {
        return description;
    }

public:
    string releaseDate;

private:
    string name;
    string description;

};

///////////////////////////////////////////////////////////////////

int main()
{
    Job defaultJob;
    defaultJob.printData();

    // -----------------------------------------------

    Job programmerJob("Programista Pythona", "Zatrudnie programiste Pythona z dwuletnim doswiadczeniem", "2018-7-14");
    programmerJob.printData();
    programmerJob.releaseDate = "2004-1-11";

    systemLog("Zmodyfikowano date wystawienia");

    programmerJob.printData();

    // -----------------------------------------------

    Job cleanerJob;
    cleanerJob.setData("Sprzatacz", "Zatrudnie sprzatacza hali gimnastycznej", "2019-2-16");

    systemLog("Ustawiono dane pracy");

    cleanerJob.printData();

    return 0;
}
