#include <iostream>
#include <time.h>

using namespace std;

string caesar(string s, int step) {
	string ns = "";

	// Letter
	char let;
	int nr, newNr, offset;
	
	for(int i=0; i<s.size(); i++) { 
		nr = s[i];
		if(nr != 32) {
			// Need for 
			offset = nr < 97 ? 65 : 97;
			nr -= offset;
			ns += (char)((26+nr+step) % 26 + offset);
		}else {
			ns += ' ';
		}
	}

	return ns;
}



int main() {

	string s;

	cout << "Wpisz tekst: ";
	getline(cin, s);
	
	
	clock_t start, stop;
	
	
	string ns = s;
	
	int counter = 50000;
	start = clock();
	
	for(int i=0; i<counter; i++) {
		ns = caesar(ns, 4);
		//cout << ns << endl;
		
		ns = caesar(ns, -4);
		//cout << ns << endl;
	}
	
	stop = clock();

	double elapsedTime = (double)(stop-start) / CLOCKS_PER_SEC;
	
	cout << "elapsed time: " << elapsedTime << " (" << counter << " times)" << endl;

	return 0;
}
