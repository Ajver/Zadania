#include <iostream>

using namespace std;

void printTask1();
void printTask2();
void printTask3();
void printTask4();

//////////////////////////////////////////

int sec_a(unsigned int n) {
    int a[2];
    a[0] = 2;
    a[1] = 1;

    if(--n < 2) {
        return a[n];
    }

    // a(n) = 2 * a(n-1) + a(n-2)
    int an;
    for(int i=1; i<n; i++) {
        an = 2*a[1] + a[0];
        a[0] = a[1];
        a[1] = an;
    }

    return an;
}

int NWD(int a, int b) {
    while(b != 0) {
        int temp = a % b;
        a = b;
        b = temp;
    }

    return a;
}

/////////////////////////////////////////

int main() {
    printTask1();
    printTask2();
    printTask3();
    printTask4();

    return 0;
}

//////////////////   TASKS  /////////////////////////////

void printTask1() {
    cout << "--- Zadanie 1 ---" << endl;
    for(int i=1; i<=6; i++)
        cout << "a(" << i << ") = " << sec_a(i) << endl;

    cout << " ... " << endl;

    cout << endl;
}

//=====================================================

void printTask2() {
    cout << "--- Zadanie 2 ---" << endl;

    int a, b;

    cout << "Podaj a: ";
    cin >> a;

    cout << "Podaj b: ";
    cin >> b;

    while(b == 0) {
        cout << endl << "b nie moze byc rowny 0!" << endl << "Podaj go ponownie: ";
        cin >> b;
    }

    int nwd = NWD(a, b);

    if(nwd != 1) {
        cout << "Ulamek " << a;
        if(b != 1) {
            cout << "/" << b;
        }

        a /= nwd;
        b /= nwd;
        cout << " po uproszczeniu: " << a;

        if(b != 1) {
            cout << "/" << b << endl;
        }else {
            cout << endl;
        }
    }else {
        cout << "Nie da sie uproscic ulamka " << a << "/" << b << endl;
    }

    cout << endl;
}

//=====================================================

void printTask3() {
    cout << "--- Zadanie 3 ---" << endl;

    int a, b;

    cout << "Podaj a: ";
    cin >> a;
    while(a < 0) {
        cout << endl << "Prosze podac liczbe naturalna!" << endl;
        cout << "Podaj a: ";
        cin >> a;
    }

    cout << "Podaj b: ";
    cin >> b;
    while(b < 0) {
        cout << endl << "Prosze podac liczbe naturalna!" << endl;
        cout << "Podaj b: ";
        cin >> b;
    }

    while(b <= a) {
        cout << endl << "Prosze podac b wieksze od " << a << endl;
        cout << "Podaj b: ";
        cin >> b;
    }

    if(a > b) {
        int temp = a;
        a = b;
        b = temp;
    }

    // Prime generator
    //-----------------------

    int range = b - a + 1;

    bool* isPrime = new bool[b+1];
    isPrime[0] = isPrime[1] = false;
    for(int i=2; i<=b; i++) { isPrime[i] = true; }

    for(int i=2; i<=b; i++) {
        if(isPrime[i]) {
            for(int j=2*i; j<=b; j+=i) {
                isPrime[j] = false;
            }
        }
    }

    cout << "Liczby pierwsze z przedzialu <" << a << "; " << b << ">:" << endl;
    for(int i=a; i<=b; i++) {
        if(isPrime[i])
            cout << i << ((i<b) ? ", " : "");
    }
    cout << endl;

    delete[] isPrime;

    //-----------------------

    cout << endl;
}

//=====================================================

void printTask4() {
    cout << "--- Zadanie 4 ---" << endl;

    int a, i = 1;

    cout << "Podaj a: ";
    cin >> a;

    while(a < 0) {
        cout << endl << "Prosze podac liczbe naturalna!" << endl;
        cout << "Podaj a: ";
        cin >> a;
    }

    for(int b=1; ; b++) {
        i *= b;

        if(i == a) {
            cout << "Istnieje liczba b, taka ze b! = a. Wynosi " << b << endl;
            break;
        }else if(i > a) {
            cout << "Nie ma takiej liczby b, ze b! = a";
            break;
        }
    }

    cout << endl;
}

