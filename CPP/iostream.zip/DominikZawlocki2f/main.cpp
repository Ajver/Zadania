#include <iostream>
#include <string>
#include <fstream>

using namespace std;

const string INPUT_FILE_NAME("narodziny.txt");
const string AVG_FILE_NAME("srednia.txt");
const string MIRROR_FILE_NAME("lustrzane.txt");
const string STATISTICS_FILE_NAME("statystyki.txt");
const string ENCODE_FILE_NAME("zaszyfrowane.txt");

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void error(string msg) {
	cout << "Error: " << msg << endl;
	system("pause");
	exit(0);
}

void displayData() {
	ifstream input(INPUT_FILE_NAME.c_str());
	
	if(!input.good()) {
		error("File not found: '" + INPUT_FILE_NAME + "'");
		return;
	}
	
	string word;
	
	while(!input.eof()) {
		input >> word;
		cout << word << endl;
	}
	
	cout << endl;
}

void countAvg() {
	ifstream input(INPUT_FILE_NAME.c_str());
	ofstream output(AVG_FILE_NAME.c_str());
	
	if(!input.good()) {
		error("File not found: '" + INPUT_FILE_NAME + "'");
		return;
	}
	
	string word;
	int num;
	int sum = 0;
	
	int i=0;
	
	while(!input.eof()) {
		if(i%4 == 0) {
			input >> word;
			output << word;
		}else {
			input >> num;
			sum += num;
		}
		if((++i)%4 == 0) {
			output << " " << (sum/3) << endl;
			sum = 0;
		}
	}
}

string mirror(string word) {
	string mirrored;
	
	for(int i=0; i<word.size(); i++) {
		mirrored += word[word.size()-1-i];
	}
	
	return mirrored;
}

void mirror() {
	ifstream input(INPUT_FILE_NAME.c_str());
	ofstream output(MIRROR_FILE_NAME.c_str());
	
	if(!input.good()) {
		error("File not found: '" + INPUT_FILE_NAME + "'");
		return;
	}
	
	string word;
	
	int i=0;
	
	while(!input.eof()) {
		input >> word;
		if(i%4 == 0) {
			output << mirror(word) << " " << endl;
		}
		i++;
	}
}

void statistics() {
	ifstream input(INPUT_FILE_NAME.c_str());
	ofstream output(STATISTICS_FILE_NAME.c_str());
	
	if(!input.good()) {
		error("File not found: '" + INPUT_FILE_NAME + "'");
		return;
	}
	
	string word;
	int num;
	int i=0;
	
	int sums[3] { 0, 0, 0 };
	int yearCounter = 0;
	
	while(!input.eof()) {
		if(i%4 != 0) {
			input >> num;
			sums[yearCounter] += num;
			yearCounter = (yearCounter+1) % 3;
		}else {
			input >> word;
		}
		i++;
	}
	
	for(i=0; i<3; i++) {
		output << (sums[i]/2) << " ";
	}	
}

string encode(string word) {
	if(word.size() < 1) {
		return "";
	}
	
	string encoded;
	
	for(int i=0; i<word.size()-1; i++) {
		encoded += word[i]; 
		encoded += char(65+i);
	}
	
	encoded += word[word.size()-1];
	
	return encoded;
}

void encode() {
	ifstream input(INPUT_FILE_NAME.c_str());
	ofstream output(ENCODE_FILE_NAME.c_str());
	
	if(!input.good()) {
		error("File not found: '" + INPUT_FILE_NAME + "'");
		return;
	}
	
	string word;
	int i=0;
		
	while(!input.eof()) {
		input >> word;
		if(i%4 == 0) {
			output << encode(word) << endl;
		}
		i++;
	}
}


int main(int argc, char** argv) {
	
	displayData();
	countAvg();
	mirror();
	statistics();
	encode();
	
	system("pause");
	
	return 0;
}
